import os
import time
time.sleep(2)
print("initializing ipower admin console updater......")
                                                        
os.system("apt update")
os.system("apt upgrade")             
os.system("pkg install git")
print("please wait........")
time.sleep(5)
print("In which platform you want to update our sofware")
print("press 1 for Termux installation")
print("press 2 for ubuntu installation")
print("press 3 for Unix installation")
input_1 = input("Enter your choice here:" )
if (input_1=="1"):
            os.system("git")
                                                                                            
else:
   print("Error 404 not found")
if (input_1=="2"):
            os.system("git")
                                                                           >
else:
   print("Error 404 not found")
if (input_1=="3"):
            os.system("git")
                                                                           >
else:
   print("Error 404 not found")
                                                                 
